/**
 * <p>A enum class for all Genres</p>
 *
 * @author Joseph Parish
 * @version 1.0.0
 */
public enum Genre
{
    FANTASY, MYSTERY, SCIENCE_FICTION, ROMANCE, NON_FICTION
}